from __future__ import absolute_import
from __future__ import print_function
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.layers.advanced_activations import PReLU, LeakyReLU
import keras.layers.advanced_activations as adact
from keras.optimizers import SGD, Adadelta, Adagrad, Adam, Adamax
from keras.utils import np_utils, generic_utils
from six.moves import range
from keras.callbacks import EarlyStopping
import pandas as pd
from keras.models import Sequential
from keras.layers.core import Dense, Activation,Dropout
import sys  
import xlwt
import xlrd
import xlutils;
from xlutils.copy import copy
from sklearn.model_selection import StratifiedKFold
import numpy as np
from sklearn import metrics
import pandas as pd
from ggplot import *
from xlwt import*
import time
import matplotlib.pyplot as plt  
import math
from sklearn.metrics import roc_curve, auc
sys.setrecursionlimit(2000)  
start=time.clock()
total_acc_results=[0,0,0,0,0,0,0,0,0,0]
total_loss_results=[0,0,0,0,0,0,0,0,0,0]
total_val_acc_results=[0,0,0,0,0,0,0,0,0,0]
total_val_loss_results=[0,0,0,0,0,0,0,0,0,0]
test_sn=[0,0,0,0,0,0,0,0,0,0]
test_sp=[0,0,0,0,0,0,0,0,0,0]
test_f1_score=[0,0,0,0,0,0,0,0,0,0]
test_mcc=[0,0,0,0,0,0,0,0,0,0]
test_acc=[0,0,0,0,0,0,0,0,0,0]
test_auc=[0,0,0,0,0,0,0,0,0,0]
test_results=[0,0,0,0,0,0,0,0,0,0]
#test_fpr=[0,0,0,0,0,0,0,0,0,0]
#test_tpr=[0,0,0,0,0,0,0,0,0,0]
def performance(testBl,preds,preds_prob,n):
    TP = 0; TN = 0; FP = 0; FN = 0  
    test_performance=[0,0,0,0,0,0]   
    for i in range(len(testBl)):
        if testBl[i] == 1 and preds[i] == 1:
            TP += 1
        if testBl[i] == 1 and preds[i] == 0:
            FN += 1
        if testBl[i] == 0 and preds[i] == 1:
            FP += 1
        if testBl[i] == 0 and preds[i] == 0:
            TN += 1
    SN = TP/(TP + FN)
    SP = TN/(FP + TN)
    F1_score=(TP+TP)/(TP+TP+FP+FN)
    #MCC = ((TP*TN)-(FP*FN))/(math.sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN)))
    ACC = (TP+TN)/(TP+FN+FP+TN)
    fpr, tpr, thresholds = metrics.roc_curve(testBl, preds_prob)
    AUC = auc(fpr,tpr)
    test_performance[0]=SN
    test_performance[1]=SP
    test_performance[2]=F1_score
    #test_performance[3]=MCC
    test_performance[4]=ACC
    test_performance[5]=AUC
    #test_performance[6]=fpr
    #test_performance[7]=tpr
    test_sn[n]=test_performance[0]
    test_sp[n]=test_performance[1]
    test_f1_score[n]=test_performance[2]
    #test_mcc[n]=test_performance[3]
    test_acc[n]=test_performance[4]
    test_auc[n]=test_performance[5]
    #test_fpr[n]=test_performance[6]
    #test_tpr[n]=test_performance[7]
    #print(test_performance)
    #print("TP的个数",TP)
    #print("TN的个数",TN)
    #print("FP的个数",FP)
    #print("FN的个数",FN)
    #print("fpr=",fpr)
    #print("tpr=",tpr)
    #return(test_fpr)
    #return(test_tpr)
    return(test_sn)
    return(test_sp)
    return(test_f1_score)
    #return(test_mcc)
    return(test_acc)
    return(test_auc)  
def cross(X_train,X_test,y_train,y_test,n,testDa,testBl,epochs_value,batch_size_value,learning_rate_value,units_value_1,units_value_2,dropout_value):

    model = Sequential()  
    #model.add(Dense(input_dim = 3, output_dim = 10))  
    model.add(Dense(units=units_value_1, input_dim=vertor_value))  
    model.add(Activation('relu'))  
    model.add(Dropout(dropout_value))
    model.add(Dense(units=units_value_2, activation='relu'))
    model.add(Dropout(dropout_value))
    #model.add(Dense(input_dim = 10, output_dim = 1))  
    model.add(Dense(input_dim=vertor_value, units=1))  
    model.add(Activation('sigmoid')) 
    '''model.add(Dense(units_value, input_dim=375, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(units_value, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(1, activation='sigmoid'))'''
   
    adam=Adam(lr=learning_rate_value)
    model.compile(loss='binary_crossentropy',
              optimizer='adam',
              metrics=['accuracy'])
    history_callback=model.fit(X_train,y_train,                
                batch_size=batch_size_value,      
                epochs=epochs_value,          
                           
                verbose=0,
                validation_data=(X_test, y_test)
                )
#print(">> Test the model ...")
    score = model.evaluate(testDa, testBl, verbose=0) 
    preds=model.predict_classes(testDa)
    preds_prob=model.predict_proba(testDa)
    performance(testBl,preds,preds_prob,n)
    history_results=[0,0,0,0]
    loss_history = history_callback.history["loss"]
    acc_history = history_callback.history["acc"]
    val_loss_history = history_callback.history["val_loss"]
    val_acc_history = history_callback.history["val_acc"]
    history_results[0]=loss_history[-1]
    history_results[1]=acc_history[-1]
    history_results[2]=val_loss_history[-1]
    history_results[3]=val_acc_history[-1]
    total_loss_results[n]=history_results[0]
    total_acc_results[n]=history_results[1]
    total_val_loss_results[n]=history_results[2]
    total_val_acc_results[n]=history_results[3]
    test_results[n]=(score[0],score[1])
    #print("test_loss&test_acc",test_results)
    #print(history_results)
    #return(test_fpr)
    #return(test_tpr)
    return(total_loss_results)
    return(total_acc_results)
    return(total_val_loss_results)
    return(total_val_acc_results)
    return(history_results)
    return(test_sn)
    return(test_sp)
    return(test_f1_score)
    #return(test_mcc)
    return(test_acc)
    return(test_auc)
    

vertor_value=1308
inputfile_train = 'input file_training datasets'
inputfile_test = 'input file_testing datasets'
inputfile_predict = 'input file_predicting datasets'
data_train = pd.read_excel(inputfile_train,header = None)#) #导入数据
data_test = pd.read_excel(inputfile_test,header = None)
data_pred = pd.read_excel(inputfile_predict,header = None)
trainDa = data_train.iloc[0:,:vertor_value].as_matrix() #待定
trainBl  = data_train.iloc[0:,vertor_value:].as_matrix()
testDa = data_test.iloc[0:,:vertor_value].as_matrix()
testBl  = data_test.iloc[0:,vertor_value:].as_matrix() 
predDa = data_pred.iloc[0:,:vertor_value]
optimal_epochs=[0,0,0,0,0]
m=0
h=0
epochs_num=[10,50,100,200,500]
batch_size_num=[10,32,64,128,256]
learning_rate=[0.01,0.001,0.00001]
units_num_1=[50,100,200,500,1000]
units_num_2=[50,100,200,500,1000]
dropout_rate=[0,0.2,0.5]
for i in learning_rate:
    learning_rate_value=i
    for i in dropout_rate:
        dropout_value=i
        for i in batch_size_num:
            batch_size_value=i
            for i in epochs_num:
                epochs_value=i
                for i in units_num_1:
                    units_value_1=i
                    for i in units_num_2:
                        units_value_2=i
                        h=h+1
                        skf = StratifiedKFold(n_splits=10)
                        n=0
                        for train_index, test_index in skf.split(trainDa, trainBl):
                                #print("TRAIN:", train_index, "TEST:", test_index)
                                X_train, X_test = trainDa[train_index], trainDa[test_index]
                                y_train, y_test = trainBl[train_index], trainBl[test_index]
                                cross(X_train,X_test,y_train,y_test,n,testDa,testBl,epochs_value,batch_size_value,learning_rate_value,units_value_1,units_value_2,dropout_value)
                                n=n+1
#optimal_epochs[m]=np.mean(test_acc)
#m=m+1
#position=np.argmax(optimal_epochs)
#print(epochs_num[position])
#print(optimal_epochs)
    #print(X_train)
    #print(X_test)
#print(total_val_acc_results)
#print("total_loss_results:",total_loss_results)
#print("total_acc_results:",total_acc_results)
#print("total_val_loss_results:",total_val_loss_results)
#print("total_val_acc_results:",total_val_acc_results)
#print("test_sn:",test_sn)
#print("test_sp:",test_sp)
#print("test_f1_score:",test_f1_score)
#print("test_mcc:",test_mcc)
#print("test_acc:",test_acc)
#print("test_auc:",test_auc)
                    print("-----------------------------------------")
                    print("-----------------------------------------")
                    print("                                         ")
                    print("轮次：",h)
                    print("epochs_value",epochs_value)
                    print("batch_size_value",batch_size_value)
                    print("learning_rate_value",learning_rate_value)
                    print("units_value",units_value)
                    print("dropout_value",dropout_value)
                    print("                                         ")
                    print("----------------------------------------")
                    #print("test_fpr",np.mean(test_fpr))
                    #print("test_tpr",np.mean(test_tpr))
                    print("ave_loss",np.mean(total_loss_results))
                    print("ave_acc",np.mean(total_acc_results))
                    print("ave_val_loss",np.mean(total_val_loss_results))
                    print("ave_val_acc",np.mean(total_val_acc_results))
                    print("ave_sn",np.mean(test_sn))
                    print("ave_sp",np.mean(test_sp))
                    print("ave_f1_score",np.mean(test_f1_score))
                    #print("ave_mcc",np.mean(test_mcc))
                    print("ave_acc",np.mean(test_acc))
                    print("ave_auc",np.mean(test_auc))
                    print("-----------------------------------------")
                    print("-----------------------------------------")
                    oldWb = xlrd.open_workbook('parameter optimization file')
                    #print (oldWb) #<xlrd.book.Book object at 0x000000000315C940>
                    newWb = copy(oldWb)
                    #print (newWb)#<xlwt.Workbook.Workbook object at 0x000000000315F470>
                    newWs = newWb.get_sheet(0)
                    newWs.write(h, 0, h)
                    newWs.write(h, 1, epochs_value)
                    newWs.write(h, 2, batch_size_value)
                    newWs.write(h, 3, learning_rate_value)
                    newWs.write(h, 4, units_value)
                    newWs.write(h, 5, dropout_value)
                    newWs.write(h, 6, np.mean(total_loss_results))
                    newWs.write(h, 7, np.mean(total_acc_results))
                    newWs.write(h, 8, np.mean(total_val_loss_results))
                    newWs.write(h, 9, np.mean(total_val_acc_results))
                    newWs.write(h, 10, np.mean(test_sn))
                    newWs.write(h, 11, np.mean(test_sp))
                    newWs.write(h, 12, np.mean(test_f1_score))
                    newWs.write(h, 13, np.mean(test_mcc))
                    newWs.write(h, 14, np.mean(test_acc))
                    newWs.write(h, 15, np.mean(test_auc))
                    #print ("write new values ok")
                    newWb.save('parameter optimization file')
                    #print ("save with same name ok")'''
preds=model.predict(predDa)
preds_prob=model.predict_proba(predDa)                    
fpr, tpr, thresholds = metrics.roc_curve(testBl, preds_prob)
roc_auc = auc(fpr,tpr)
#print(np.mean(roc_auc))
plt.figure()  
lw = 5  
plt.figure(figsize=(10,10))  
plt.plot(fpr, tpr, color='darkorange',  
         lw=lw, label='ROC curve (area = %0.2f)' % roc_auc) ###假正率为横坐标，真正率为纵坐标做曲线  
plt.plot([0, 1], [0, 1], color='red', lw=lw, linestyle='--')  
plt.xlim([0.0, 1.0])  
plt.ylim([0.0, 1.05])  
plt.xlabel('False Positive Rate')  
plt.ylabel('True Positive Rate')  
plt.title('Receiver operating characteristic example')  
plt.legend(loc="lower right")  
plt.show()  
plt.figure()
plt.figure(figsize=(30,5))
plt.plot(preds,'r*')
plt.plot(testBl,'o')
plt.grid(True)
plt.xlabel('Test Sample')
plt.ylabel('Category label')
plt.title('The comparison between preds and test sample')
plt.show()                    
                                   
end=time.clock()
print('Running time: %s Seconds'%(end-start))
model.save('model parameter file')
model.save_weights('model weights file')
preds.to_excel('output file',index=False,header=None)
print (model.get_weights())
np.set_printoptions(threshold = 1e6)









