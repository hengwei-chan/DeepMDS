from __future__ import absolute_import
from __future__ import print_function
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.layers.advanced_activations import PReLU, LeakyReLU
import keras.layers.advanced_activations as adact
from keras.layers.convolutional import Convolution2D, MaxPooling2D
from keras.optimizers import SGD, Adadelta, Adagrad, Adam, Adamax
from keras.utils import np_utils, generic_utils
from six.moves import range
from keras.callbacks import EarlyStopping
import pandas as pd
from keras.models import Sequential
from keras.layers.core import Dense, Activation,Dropout
import sys  
sys.setrecursionlimit(2000)  
import scipy
import numpy
import numpy as np 
from keras import regularizers
from sklearn import preprocessing
import time
from keras.callbacks import EarlyStopping
#from keras.regularizers import l2, activity_l2
#keras.regularizers.WeightRegularizer(l1=0., l2=0.)
#keras.regularizers.ActivityRegularizer(l1=0., l2=0.)
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
#参数初始化
start=time.clock()
def figures(history,figure_name="plots"):
    """ method to visualize accuracies and loss vs epoch for training as well as testind data\n
        Argumets: history     = an instance returned by model.fit method\n
                  figure_name = a string representing file name to plots. By default it is set to "plots" \n
       Usage: hist = model.fit(X,y)\n              figures(hist) """
    from keras.callbacks import History
    if isinstance(history,History):
        import matplotlib.pyplot as plt
        hist     = history.history 
        epoch    = history.epoch
        mean_absolute_error     = hist['mean_absolute_error']
        loss     = hist['loss']
        val_mean_absolute_error = hist['val_mean_absolute_error']
        val_mean_squared_error  = hist['val_mean_squared_error']
        plt.figure(1,figsize=(10,10))
 
        plt.subplot(221)
        plt.plot(epoch,mean_absolute_error)
        plt.title("Training mae vs Epoch")
        plt.xlabel("Epoch")
        plt.ylabel("mae")     
 
        plt.subplot(222)
        plt.plot(epoch,loss)
        plt.title("Training loss vs Epoch")
        plt.xlabel("Epoch")
        plt.ylabel("Loss")  
 
        plt.subplot(223)
        plt.plot(epoch,val_mean_absolute_error)
        plt.title("Validation mae vs Epoch")
        plt.xlabel("Epoch")
        plt.ylabel("Validation mae")  
 
        plt.subplot(224)
        plt.plot(epoch,val_mean_squared_error)
        plt.title("Validation mse vs Epoch")
        plt.xlabel("Epoch")
        plt.ylabel("Validation mse")  
        plt.tight_layout()
        plt.savefig(figure_name)
    else:
        print ('Input Argument is not an instance of class History')
ertor_value=1308
inputfile_train = 'input file_training datasets'
inputfile_test = 'input file_testing datasets'
inputfile_predict = 'input file_predicting datasets'
data_train = pd.read_excel(inputfile_train,header = None)#) #导入数据
data_test = pd.read_excel(inputfile_test,header = None)
data_pred = pd.read_excel(inputfile_predict,header = None)
trainDa = data_train.iloc[0:,:vertor_value].as_matrix() #待定
trainBl  = data_train.iloc[0:,vertor_value:].as_matrix()
testDa = data_test.iloc[0:,:vertor_value].as_matrix()
testBl  = data_test.iloc[0:,vertor_value:].as_matrix() 
predDa = data_pred.iloc[0:,:vertor_value]
scaler = StandardScaler().fit(trainDa)
trainDa = scaler.transform(trainDa)
scaler = StandardScaler().fit(testDa)
testDa = scaler.transform(testDa)
# summarize transformed data
numpy.set_printoptions(precision=3)
optimal_epochs=[0,0,0,0,0]
m=0
h=0
epochs_num=[10,50,100,200,500]
batch_size_num=[10,32,64,128,256]
learning_rate=[0.01,0.001,0.00001]
units_num_1=[50,100,200,500,1000]
units_num_2=[50,100,200,500,1000]
dropout_rate=[0,0.2,0.5]
for i in learning_rate:
    learning_rate_value=i
    for i in dropout_rate:
        dropout_value=i
        for i in batch_size_num:
            batch_size_value=i
            for i in epochs_num:
                epochs_value=i
                for i in units_num_1:
                    units_value_1=i
                    for i in units_num_2:
                        units_value_2=i
                        h=h+1
                        skf = StratifiedKFold(n_splits=10)
                        n=0
                        for train_index, test_index in skf.split(trainDa, trainBl):
                                #print("TRAIN:", train_index, "TEST:", test_index)
                                X_train, X_test = trainDa[train_index], trainDa[test_index]
                                y_train, y_test = trainBl[train_index], trainBl[test_index]
                                cross(X_train,X_test,y_train,y_test,n,testDa,testBl,epochs_value,batch_size_value,learning_rate_value,units_value_1,units_value_2,dropout_value)
                                n=n+1

np.set_printoptions(threshold = 1e6)
#print(trainBl)
#print(testBl)
#print(trainDa)
#print(testDa)
#print(rescaledX[0:5,:])
def cross(X_train,X_test,y_train,y_test,n,testDa,testBl,epochs_value,batch_size_value,learning_rate_value,units_value_1,units_value_2,dropout_value):

    model = Sequential()  
    #model.add(Dense(input_dim = 3, output_dim = 10))  
    model.add(Dense(units=units_value_1, input_dim=vertor_value))  
    model.add(Activation('relu'))  
    model.add(Dropout(dropout_value))
    model.add(Dense(units=units_value_2, activation='relu'))
    model.add(Dropout(dropout_value))
    #model.add(Dense(input_dim = 10, output_dim = 1))  
    model.add(Dense(input_dim=vertor_value, units=1))  
    model.add(Activation('linear')) 
    adam=Adam(lr=learning_rate_value)
    model.compile(loss='mse',
              optimizer='Adam',
              metrics=['mse','mae','acc'])
    history_callback=model.fit(X_train,y_train,                
                batch_size=batch_size_value,      
                epochs=epochs_value,          
                           
                verbose=0,
                validation_data=(X_test, y_test)
                )
#print(">> Test the model ...")
    score = model.evaluate(testDa, testBl, verbose=0) 
    preds=model.predict_classes(testDa)
    preds_prob=model.predict_proba(testDa)
    performance(testBl,preds,preds_prob,n)
    history_results=[0,0,0,0]
    loss_history = history_callback.history["loss"]
    mse_history = history_callback.history["mse"]
    val_loss_history = history_callback.history["val_loss"]
    val_mse_history = history_callback.history["val_mse"]
print(">> Test the model ...")
score = model.evaluate(testDa, testBl, verbose=0) 
#preds=model.predict(data_predict)
#preds_prob=model.predict_proba(testDa)
print('Test loss:', score[0])
print('Test mae:', score[2])
#print(preds)
######################################
#     保存ConvNets模型
######################################
fig, ax = plt.subplots()
ax.plot(n, testBl,'r')
ax.plot(n, preds, 'k--', lw=4)
ax.set_xlabel('Measured')
ax.set_ylabel('Predicted')


print (model.get_weights())
np.set_printoptions(threshold = 1e6)
file=open('C:/Users/Mac/Desktop/panghui/weights.txt','w')
file.write(str(model.get_weights()));
file.close()
end=time.clock()
print('Running time: %s Seconds'%(end-start))
plt.show()
figures(hist)